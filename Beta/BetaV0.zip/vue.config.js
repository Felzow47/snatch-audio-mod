module.exports = {
  publicPath: "./",
  configureWebpack: {
    target: "node-webkit",
    node: false
  },
  lintOnSave: false
};